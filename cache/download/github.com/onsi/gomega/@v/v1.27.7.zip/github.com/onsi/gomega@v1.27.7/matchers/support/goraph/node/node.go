package node

type Node struct {
	ID    int
	Value interface{}
}

type NodeOrderedSet []Node
