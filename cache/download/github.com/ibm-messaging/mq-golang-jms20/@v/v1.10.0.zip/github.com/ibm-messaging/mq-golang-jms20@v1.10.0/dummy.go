//go:build ignore
// +build ignore

package main

func main() {}

// Prevent error message about "no non-test Go files in <dir>"
