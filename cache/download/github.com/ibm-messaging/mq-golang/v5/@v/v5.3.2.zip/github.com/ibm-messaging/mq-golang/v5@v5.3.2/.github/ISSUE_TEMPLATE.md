Please include the following information in your ticket.

- Version information for MQ, mq-golang, Go compiler
- A small code sample that demonstrates the issue.
