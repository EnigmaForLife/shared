package ramsql

//
// Tx doesn't need to be in driver package.
//
// Implementation doesn't depend on any sql/driver type, and can live in executor package.
//
