package parser

import (
//"github.com/proullon/ramsql/engine/log"
)

func debug(format string, v ...interface{}) {
	//log.Debug(format, v...)
}
