# PKCS7

This code is used to verify PKCS7 signatures for the EC2 auth method. The code 
was forked from [mozilla-services/pkcs7](https://github.com/mozilla-services/pkcs7) 
and modified for Vault.