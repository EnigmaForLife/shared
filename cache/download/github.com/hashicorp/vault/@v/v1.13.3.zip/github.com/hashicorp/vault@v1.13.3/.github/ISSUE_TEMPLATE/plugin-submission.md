---
name: Plugin Submission
about: Submit a community Vault plugin!
title: "[Plugin Portal] Plugin Submission - <PLUGIN NAME>"
labels: ecosystem/plugin
assignees: ''

---

Please provide details for the plugin to be listed. All fields are required for a submission to be included in the [Plugin Portal](https://www.vaultproject.io/docs/plugin-portal) page.

**Plugin Information**
Name as it would appear listed:
Plugin type (secrets/auth/database):
Repository link:
