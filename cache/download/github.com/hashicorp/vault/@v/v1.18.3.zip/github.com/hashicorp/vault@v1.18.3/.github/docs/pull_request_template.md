### Description
Why is this docs change needed?

### TODO
- [ ] Preview the changes you made either locally or in the Vercel deployment
  and make sure it looks correct.
- [ ] If you've added a new link to the sidebar navigation, make sure it's
  sorted correctly.
