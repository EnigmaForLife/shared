## 0.7.5 (Nov 8, 2023)

BUG FIXES

- client: fixes an issue where the request body is not preserved on temporary redirects or re-established HTTP/2 connections [GH-207]

## 0.7.4 (Jun 6, 2023)

BUG FIXES

- client: fixing an issue where the Content-Type header wouldn't be sent with an empty payload when using HTTP/2 [GH-194]

## 0.7.3 (May 15, 2023)

Initial release
