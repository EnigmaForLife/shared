FlatBuffers swift can be found in both SPM

`.package(url: "https://github.com/google/flatbuffers.git", from: "X.Y.Z"),`

and Cocoapods

`pod 'FlatBuffers'`

### Contribute

1- Always run `swift test --generate-linuxmain` whenever new test functions are added or removed