#ifndef FLATBUFFERS_NAMER_H_
#define FLATBUFFERS_NAMER_H_

#include "codegen/namer.h"

#endif  // FLATBUFFERS_NAMER_H_
