# Benchmarks

To open the benchmarks in xcode use:

`open --env BENCHMARK_DISABLE_JEMALLOC=true Package.swift`

or running them directly within terminal using:

`swift package benchmark`