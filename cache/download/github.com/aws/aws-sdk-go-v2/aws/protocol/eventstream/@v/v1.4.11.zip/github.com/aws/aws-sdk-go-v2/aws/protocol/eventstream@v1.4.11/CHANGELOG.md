# v1.4.11 (2023-07-31)

* No change notes available for this release.

# v1.4.10 (2022-12-02)

* No change notes available for this release.

# v1.4.9 (2022-10-24)

* No change notes available for this release.

# v1.4.8 (2022-09-14)

* No change notes available for this release.

# v1.4.7 (2022-09-02)

* No change notes available for this release.

# v1.4.6 (2022-08-31)

* No change notes available for this release.

# v1.4.5 (2022-08-29)

* No change notes available for this release.

# v1.4.4 (2022-08-09)

* No change notes available for this release.

# v1.4.3 (2022-06-29)

* No change notes available for this release.

# v1.4.2 (2022-06-07)

* No change notes available for this release.

# v1.4.1 (2022-03-24)

* No change notes available for this release.

# v1.4.0 (2022-03-08)

* **Feature**: Updated `github.com/aws/smithy-go` to latest version

# v1.3.0 (2022-02-24)

* **Feature**: Updated `github.com/aws/smithy-go` to latest version

# v1.2.0 (2022-01-14)

* **Feature**: Updated `github.com/aws/smithy-go` to latest version

# v1.1.0 (2022-01-07)

* **Feature**: Updated `github.com/aws/smithy-go` to latest version

# v1.0.0 (2021-11-06)

* **Announcement**: Support has been added for AWS EventStream APIs for Kinesis, S3, and Transcribe Streaming. Support for the Lex Runtime V2 EventStream API will be added in a future release.
* **Release**: Protocol support has been added for AWS event stream.
* **Feature**: Updated `github.com/aws/smithy-go` to latest version

