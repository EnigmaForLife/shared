# v1.1.32 (2023-07-31)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.31 (2023-07-28)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.30 (2023-07-13)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.29 (2023-06-13)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.28 (2023-04-24)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.27 (2023-04-07)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.26 (2023-03-21)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.25 (2023-03-10)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.24 (2023-02-20)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.23 (2023-02-03)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.22 (2022-12-15)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.21 (2022-12-02)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.20 (2022-10-24)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.19 (2022-10-21)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.18 (2022-09-20)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.17 (2022-09-14)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.16 (2022-09-02)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.15 (2022-08-31)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.14 (2022-08-29)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.13 (2022-08-11)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.12 (2022-08-09)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.11 (2022-08-08)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.10 (2022-08-01)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.9 (2022-07-05)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.8 (2022-06-29)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.7 (2022-06-07)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.6 (2022-05-17)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.5 (2022-04-27)

* **Bug Fix**: Fixes a bug that could cause the SigV4 payload hash to be incorrectly encoded, leading to signing errors.

# v1.1.4 (2022-04-25)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.3 (2022-03-30)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.2 (2022-03-24)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.1 (2022-03-23)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.0 (2022-03-08)

* **Feature**:  Updates the SDK's checksum validation logic to require opt-in to output response payload validation. The SDK was always preforming output response payload checksum validation, not respecting the output validation model option. Fixes [#1606](https://github.com/aws/aws-sdk-go-v2/issues/1606)
* **Feature**: Updated `github.com/aws/smithy-go` to latest version
* **Dependency Update**: Updated to the latest SDK module versions

# v1.0.0 (2022-02-24)

* **Release**: New module for computing checksums
* **Feature**: Updated `github.com/aws/smithy-go` to latest version
* **Dependency Update**: Updated to the latest SDK module versions

