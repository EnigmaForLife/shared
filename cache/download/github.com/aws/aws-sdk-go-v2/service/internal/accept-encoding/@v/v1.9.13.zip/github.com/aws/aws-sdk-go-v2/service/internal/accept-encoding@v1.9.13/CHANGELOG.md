# v1.9.13 (2023-08-07)

* No change notes available for this release.

# v1.9.12 (2023-07-31)

* No change notes available for this release.

# v1.9.11 (2022-12-02)

* No change notes available for this release.

# v1.9.10 (2022-10-24)

* No change notes available for this release.

# v1.9.9 (2022-09-14)

* No change notes available for this release.

# v1.9.8 (2022-09-02)

* No change notes available for this release.

# v1.9.7 (2022-08-31)

* No change notes available for this release.

# v1.9.6 (2022-08-29)

* No change notes available for this release.

# v1.9.5 (2022-08-11)

* No change notes available for this release.

# v1.9.4 (2022-08-09)

* No change notes available for this release.

# v1.9.3 (2022-06-29)

* No change notes available for this release.

# v1.9.2 (2022-06-07)

* No change notes available for this release.

# v1.9.1 (2022-03-24)

* No change notes available for this release.

# v1.9.0 (2022-03-08)

* **Feature**: Updated `github.com/aws/smithy-go` to latest version

# v1.8.0 (2022-02-24)

* **Feature**: Updated `github.com/aws/smithy-go` to latest version

# v1.7.0 (2022-01-14)

* **Feature**: Updated `github.com/aws/smithy-go` to latest version

# v1.6.0 (2022-01-07)

* **Feature**: Updated `github.com/aws/smithy-go` to latest version

# v1.5.0 (2021-11-06)

* **Feature**: Updated `github.com/aws/smithy-go` to latest version

# v1.4.0 (2021-10-21)

* **Feature**: Updated  to latest version

# v1.3.0 (2021-08-27)

* **Feature**: Updated `github.com/aws/smithy-go` to latest version

# v1.2.2 (2021-08-04)

* **Dependency Update**: Updated `github.com/aws/smithy-go` to latest version.

# v1.2.1 (2021-07-15)

* **Dependency Update**: Updated `github.com/aws/smithy-go` to latest version

# v1.2.0 (2021-06-25)

* **Feature**: Updated `github.com/aws/smithy-go` to latest version

# v1.1.0 (2021-05-14)

* **Feature**: Constant has been added to modules to enable runtime version inspection for reporting.

