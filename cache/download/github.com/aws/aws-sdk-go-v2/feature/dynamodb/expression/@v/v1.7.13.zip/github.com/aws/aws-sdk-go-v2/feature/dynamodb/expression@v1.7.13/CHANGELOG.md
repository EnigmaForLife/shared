# v1.7.13 (2024-03-29)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.7.12 (2024-03-25)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.7.11 (2024-03-20)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.7.10 (2024-03-18)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.7.9 (2024-03-07)

* **Bug Fix**: Remove dependency on go-cmp.
* **Dependency Update**: Updated to the latest SDK module versions

# v1.7.8 (2024-03-06)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.7.7 (2024-03-04)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.7.6 (2024-02-23)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.7.5 (2024-02-22)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.7.4 (2024-02-21)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.7.3 (2024-02-20)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.7.2 (2024-02-16)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.7.1 (2024-02-15)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.7.0 (2024-02-13)

* **Feature**: Bump minimum Go version to 1.20 per our language support policy.
* **Dependency Update**: Updated to the latest SDK module versions

# v1.6.17 (2024-02-02)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.6.16 (2024-01-19)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.6.15 (2024-01-17)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.6.14 (2024-01-04)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.6.13 (2023-12-20)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.6.12 (2023-12-08)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.6.11 (2023-12-07)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.6.10 (2023-12-06)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.6.9 (2023-12-01)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.6.8 (2023-11-30.2)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.6.7 (2023-11-30)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.6.6 (2023-11-29)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.6.5 (2023-11-28.2)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.6.4 (2023-11-28)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.6.3 (2023-11-20)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.6.2 (2023-11-15)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.6.1 (2023-11-09)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.6.0 (2023-11-01)

* **Feature**: Adds support for configured endpoints via environment variables and the AWS shared configuration file.
* **Dependency Update**: Updated to the latest SDK module versions

# v1.5.0 (2023-10-31)

* **Feature**: **BREAKING CHANGE**: Bump minimum go version to 1.19 per the revised [go version support policy](https://aws.amazon.com/blogs/developer/aws-sdk-for-go-aligns-with-go-release-policy-on-supported-runtimes/).
* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.71 (2023-10-20)

* No change notes available for this release.

# v1.4.70 (2023-10-18)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.69 (2023-10-12)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.68 (2023-10-06)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.67 (2023-09-26)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.66 (2023-08-21)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.65 (2023-08-18)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.64 (2023-08-17)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.63 (2023-08-07)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.62 (2023-08-01)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.61 (2023-07-31)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.60 (2023-07-28)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.59 (2023-07-25)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.58 (2023-07-13)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.57 (2023-06-29)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.56 (2023-06-21)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.55 (2023-06-15)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.54 (2023-06-13)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.53 (2023-06-12)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.52 (2023-05-08)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.51 (2023-05-04)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.50 (2023-04-24)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.49 (2023-04-17)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.48 (2023-04-10)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.47 (2023-04-07)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.46 (2023-03-21)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.45 (2023-03-10)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.44 (2023-03-08)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.43 (2023-03-03)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.42 (2023-02-22)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.41 (2023-02-20)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.40 (2023-02-17)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.39 (2023-02-15)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.38 (2023-02-03)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.37 (2023-02-01)

* No change notes available for this release.

# v1.4.36 (2023-01-23)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.35 (2023-01-05)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.34 (2022-12-15)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.33 (2022-12-02)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.32 (2022-11-22)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.31 (2022-11-18)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.30 (2022-11-16)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.29 (2022-11-10)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.28 (2022-10-24)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.27 (2022-10-21)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.26 (2022-09-26)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.25 (2022-09-20)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.24 (2022-09-15)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.23 (2022-09-14)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.22 (2022-09-02)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.21 (2022-08-31)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.20 (2022-08-30)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.19 (2022-08-29)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.18 (2022-08-18)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.17 (2022-08-11)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.16 (2022-08-09)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.15 (2022-08-08)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.14 (2022-08-01)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.13 (2022-07-22)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.12 (2022-07-05)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.11 (2022-06-29)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.10 (2022-06-17)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.9 (2022-06-07)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.8 (2022-05-17)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.7 (2022-04-25)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.6 (2022-04-15)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.5 (2022-03-31)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.4 (2022-03-30)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.3 (2022-03-24)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.2 (2022-03-23)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.1 (2022-03-08)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.4.0 (2022-02-24)

* **Feature**: Add support for expression names with dots via new NameBuilder function NameNoDotSplit, related to [aws/aws-sdk-go#2570](https://github.com/aws/aws-sdk-go/issues/2570)
* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.7 (2022-01-14)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.6 (2022-01-07)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.5 (2021-12-21)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.4 (2021-12-02)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.3 (2021-11-30)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.2 (2021-11-19)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.1 (2021-11-12)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.0 (2021-11-06)

* **Feature**: The SDK now supports configuration of FIPS and DualStack endpoints using environment variables, shared configuration, or programmatically.
* **Dependency Update**: Updated to the latest SDK module versions

# v1.2.6 (2021-10-21)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.2.5 (2021-10-11)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.2.4 (2021-09-24)

* **Documentation**: Fixes typo in NameBuilder.NamesList example documentation to use the correct variable name.

# v1.2.3 (2021-09-17)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.2.2 (2021-08-27)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.2.1 (2021-08-19)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.2.0 (2021-08-04)

* **Feature**: Add IsSet helper for ConditionBuilder and KeyConditionBuilder ([#1329](https://github.com/aws/aws-sdk-go-v2/pull/1329))
* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.3 (2021-07-15)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.2 (2021-06-25)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.1 (2021-05-20)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.0 (2021-05-14)

* **Feature**: Constant has been added to modules to enable runtime version inspection for reporting.
* **Dependency Update**: Updated to the latest SDK module versions

