package aws

// TODO put tests for SDK retry behavior with request.
