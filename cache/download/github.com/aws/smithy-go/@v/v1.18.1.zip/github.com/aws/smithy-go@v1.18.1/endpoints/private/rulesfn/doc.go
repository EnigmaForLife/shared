// Package rulesfn provides endpoint rule functions for evaluating endpoint
// resolution rules.

package rulesfn
