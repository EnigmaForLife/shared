# go-jose v2

Version 2 of this library is no longer supported. [Please use v4
instead](https://pkg.go.dev/github.com/go-jose/go-jose/v4).
