//go:build windows
// +build windows

package generate

type sharedOptions struct {
	sharedOptionsCommon
}
