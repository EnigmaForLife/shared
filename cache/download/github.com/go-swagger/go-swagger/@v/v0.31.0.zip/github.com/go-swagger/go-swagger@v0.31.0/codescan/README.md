# codescan

Version of the go source parser with support for go modules, from go1.11 onwards.
