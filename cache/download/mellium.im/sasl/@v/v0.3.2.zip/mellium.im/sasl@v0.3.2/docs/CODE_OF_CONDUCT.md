# Code of Conduct

The Code of Conduct for all Mellium projects can be found in the main repo under
[`docs/CODE_OF_CONDUCT.md`].

[`docs/CODE_OF_CONDUCT.md`]: https://mellium.im/docs/CODE_OF_CONDUCT
