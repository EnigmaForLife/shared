# Contributing

Thanks for wanting to contribute to Mellium! Before submitting a patch, please
read the [Code of Conduct] and the [Contributing Guide] from the main repo.

[Code of Conduct]: https://mellium.im/docs/CODE_OF_CONDUCT
[Contributing Guide]: https://mellium.im/docs/CONTRIBUTING
