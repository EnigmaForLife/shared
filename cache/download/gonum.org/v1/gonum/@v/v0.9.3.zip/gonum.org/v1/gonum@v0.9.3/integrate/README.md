# Gonum integrate [![GoDoc](https://godoc.org/gonum.org/v1/gonum/integrate?status.svg)](https://godoc.org/gonum.org/v1/gonum/integrate)

Package integrate provides numerical evaluation of definite integrals of single-variable functions for the Go programming language.
