Multivariate linear regression example.

See [gorgonia.org/tutorials/iris/](gorgonia.org/tutorials/iris/) for more info
