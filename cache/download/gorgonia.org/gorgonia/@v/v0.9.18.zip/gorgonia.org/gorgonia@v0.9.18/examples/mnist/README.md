This package contains primitives to read the mnist dataset as exposed on [Yann LeCun's website](

It exposes a single `Load` method that creates tensors from the data sets.

Take a look at the [convnet](../convnet) directoy for a neural net implementation using the mnist dataset.

more info on the Gorgonia website: [https://gorgonia.org/tutorials/mnist/](https://gorgonia.org/tutorials/mnist/)
