#Blastoise#

blastoise is a very simple wrapper package around [gonum/blas](http://github.com/gonum/blas). It implements a buffer so that cgo calls are batched. A similar design is done for Cubone.