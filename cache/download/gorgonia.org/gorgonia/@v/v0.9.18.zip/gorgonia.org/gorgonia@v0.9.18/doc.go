/*
Package gorgonia is a library that helps facilitate machine learning in Go.
Write and evaluate mathematical equations involving multidimensional arrays easily.
Do differentiation with them just as easily.
*/
package gorgonia
