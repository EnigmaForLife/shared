
1. Please ensure you have cuDNN Developer Packages installed.
2. `usr/include/x86_64-linux-gnu/cudnn_v7.h to provide /usr/include/cudnn.h`