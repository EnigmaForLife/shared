package main

// errors for reporting. Use global variables for all the things!

var errs = make(map[string]struct{})
