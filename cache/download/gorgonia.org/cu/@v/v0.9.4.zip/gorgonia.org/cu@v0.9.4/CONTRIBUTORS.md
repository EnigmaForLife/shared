# Significant Contributors #

Much thanks goes to the following significant contributors of this project, listed in alphabetical order of last names (if available, otherwise, the github username is used)

* abeltensor - cgopaths
* Xuanyi Chew (@chewxy) - package maintainer
* Egon Elbre (@egonelbre) - ported many APIs to the repository
