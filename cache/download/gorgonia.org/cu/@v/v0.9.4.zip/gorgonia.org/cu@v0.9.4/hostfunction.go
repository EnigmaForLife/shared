package cu

// HostFunction is a closure of a function call with its data.
type HostFunction func()
