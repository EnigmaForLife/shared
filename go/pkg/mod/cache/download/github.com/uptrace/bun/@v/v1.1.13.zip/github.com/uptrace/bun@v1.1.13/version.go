package bun

// Version is the current release version.
func Version() string {
	return "1.1.13"
}
