package evCheckerWorker

// EvCheckerBinaryName is the path to the ev-checker binary the worker should use
var EvCheckerBinaryName = "ev-checker"
