module.exports = {
    "env": {
        "browser": true
    },
    "extends": "fxa",
    rules: {
        'indent': ['error', 4]
    }
};
