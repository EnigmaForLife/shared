// Package dot creates a graphviz compatible version of the ExprGraph
package dot
