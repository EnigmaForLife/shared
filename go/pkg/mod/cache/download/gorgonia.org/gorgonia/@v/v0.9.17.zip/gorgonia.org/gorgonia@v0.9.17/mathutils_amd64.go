package gorgonia

func divmod(a, b int) (q, r int)
