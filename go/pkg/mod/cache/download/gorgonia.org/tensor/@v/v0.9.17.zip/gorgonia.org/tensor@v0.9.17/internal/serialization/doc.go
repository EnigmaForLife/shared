// package serialization provides the data structures for serialization
package serialization
