package testdata

func Foo038() bool { return false }
