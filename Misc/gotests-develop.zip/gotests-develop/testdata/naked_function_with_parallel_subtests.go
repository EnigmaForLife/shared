package testdata

func main() {
	do()
}

func do() {

}
