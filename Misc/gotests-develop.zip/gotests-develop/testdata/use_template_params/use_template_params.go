package use_template_params

import "fmt"

// Do ...
func Do(a int, name string) {
	fmt.Println(a, name)
}
