package testdata

func Foo16(in Bazzar) Bazzar { return &baz{} }
